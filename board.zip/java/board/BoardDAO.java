package board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.DriverManager;
//import java.util.ArrayList;

public class BoardDAO {
	
	private Connection conn;
	private ResultSet rs;
	private PreparedStatement pstmt;
	
	public BoardDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/tmp";
			String dbID = "root";
			String dbPassword = "root";
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn=DriverManager.getConnection(dbURL,dbID,dbPassword);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<Board> getTmp() {
		String SQL = "SELECT * FROM tmp ORDER BY docNum";
		ArrayList<Board> list = new ArrayList<Board>();
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				Board board=new Board();
				board.setDocNum(rs.getInt(1));
				board.setDocTitle(rs.getString(2));
				board.setDocContent(rs.getString(3));
				list.add(board);
			}
		}catch (Exception e) {
			e.printStackTrace();			
		}
		return list;
		
	}
	
	public Board getDoc(int docNum) {
		String SQL = "SELECT * FROM tmp WHERE docNum=? ORDER BY docNum DESC";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, docNum);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				Board board=new Board();
				board.setDocNum(rs.getInt(1));
				board.setDocTitle(rs.getString(2));
				board.setDocContent(rs.getString(3));				
				return board;
			}
		}catch (Exception e) {
			e.printStackTrace();			
		}		
		
		return null;
	}
	
	public int nextDocNum() {
		String SQL = "SELECT docNum FROM tmp ORDER BY docNum DESC";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);			
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;	
			}else {
				return 1;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	return -1;
	}
	
	public int docWrite(String docTitle,String docContent) {
		String SQL = "INSERT INTO tmp VALUES(?,?,?,?,?)";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, nextDocNum());
			pstmt.setString(2, docTitle);
			pstmt.setString(3, docContent);
			pstmt.setString(4, "2022-03-25");
			pstmt.setInt(5, 1);
			return pstmt.executeUpdate();			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
}







