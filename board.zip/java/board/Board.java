package board;

public class Board {
	private int docNum;
	private String docTitle;
	private String docContent;
	private String docDate;
	private Boolean docFlag;
	
	public int getDocNum() {
		return docNum;
	}
	public void setDocNum(int docNum) {
		this.docNum = docNum;
	}
	public String getDocTitle() {
		return docTitle;
	}
	public void setDocTitle(String docTitle) {
		this.docTitle = docTitle;
	}
	public String getDocContent() {
		return docContent;
	}
	public void setDocContent(String docContent) {
		this.docContent = docContent;
	}
	public String getDocDate() {
		return docDate;
	}
	public void setDocDate(String docDate) {
		this.docDate = docDate;
	}
	public Boolean getDocFlag() {
		return docFlag;
	}
	public void setDocFlag(Boolean docFlag) {
		this.docFlag = docFlag;
	}
	
}
